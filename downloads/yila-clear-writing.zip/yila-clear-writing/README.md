# Yila Clear Writing · 安装与使用

60 套双语提示词、24 组情景案例。安装后调用 Skill，或打开 references 文件夹复制提示词。

## Windows

在本文件夹打开 PowerShell，选择客户端：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Agent codex
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Agent claude
```

## macOS / Linux

```bash
bash ./install.sh --agent codex
bash ./install.sh --agent claude
```

Choose the command for your client. The installer prints its destination.
Defaults: Codex `~/.agents/skills`, Claude Code `~/.claude/skills`.
Use `-Dest` / `--dest` for a custom parent skills directory.
Add `-Force` / `--force` when updating; the installer retains the previous version.
Backups are stored in yila-clear-writing-backups beside the skills directory.

重新打开客户端。Codex 中用 `$yila-clear-writing`，Claude Code 中用 `/yila-clear-writing`。

[中文调用指南](guides/USAGE.zh-CN.md) · [English usage guide](guides/USAGE.md)

网页对话可复制 [中文通用指令](guides/WEB-PROMPT.zh-CN.md) 或 [English web instructions](guides/WEB-PROMPT.md)。

Reopen the client. Invoke `$yila-clear-writing` in Codex or `/yila-clear-writing` in Claude Code.
For manual installation, copy this entire folder into the client's skills directory.
To remove, delete the installed yila-clear-writing folder and reopen the client.

[Yila](https://yila.ai/research) · [OpenAI installation paths](https://learn.chatgpt.com/docs/build-skills) · [Claude Code skills](https://code.claude.com/docs/en/skills)
