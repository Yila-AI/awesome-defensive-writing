# Yila Clear Writing

**English** | [简体中文](README.zh-CN.md)

60 bilingual prompts and 25 worked scenarios. Invoke the installed skill or open references to copy a template.

## Install on Windows

Open PowerShell in the folder containing install.ps1. Choose the command for your client:

**Codex**

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Agent codex
```

**Claude Code**

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Agent claude
```

## Install on macOS / Linux

Open the folder containing install.sh and choose your command:

```bash
# Codex
bash ./install.sh --agent codex

# Claude Code
bash ./install.sh --agent claude
```

## Destinations and updates

Codex defaults to `~/.agents/skills/yila-clear-writing`; Claude Code defaults to `~/.claude/skills/yila-clear-writing`.

Use `-Dest` or `--dest` to supply a custom parent skills directory:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Dest "D:\My Project\.agents\skills"
```

```bash
bash ./install.sh --dest "/path/to/project/.agents/skills"
```

Add `-Force` or `--force` to update. The previous version is retained in yila-clear-writing-backups beside the skills directory; the installer prints its path.

For manual installation, copy the entire yila-clear-writing folder into your client's skills directory. To remove it, delete the installed folder and reopen the client.

## Invoke

Reopen your client and send:

```text
Codex: $yila-clear-writing Revise this passage…
Claude Code: /yila-clear-writing Revise this passage…
```

[Full usage guide](guides/USAGE.md) · [Standalone web instructions](guides/WEB-PROMPT.md)

## Open source by Yila

Copy a template and send it with your research material to the [Yila workbench](https://yila.ai/research).

[Licensing](LICENSE.md) · [OpenAI installation paths](https://learn.chatgpt.com/docs/build-skills) · [Claude Code skills](https://code.claude.com/docs/en/skills)
