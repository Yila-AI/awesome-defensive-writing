# Yila Clear Writing

[English](README.md) | **简体中文**

60 套双语提示词、25 组情景案例。安装后按名称调用，也可以打开 references 文件夹复制模板。

## Windows 安装

进入包含 install.ps1 的文件夹，打开 PowerShell。选择对应客户端的命令：

**Codex**

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Agent codex
```

**Claude Code**

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Agent claude
```

## macOS / Linux 安装

进入包含 install.sh 的文件夹，选择对应命令：

```bash
# Codex
bash ./install.sh --agent codex

# Claude Code
bash ./install.sh --agent claude
```

## 安装目录与更新

Codex 默认安装到 `~/.agents/skills/yila-clear-writing`；Claude Code 默认安装到 `~/.claude/skills/yila-clear-writing`。

自定义目录使用 `-Dest "路径"` 或 `--dest "路径"`，传入 skills 的父目录。例如：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Dest "D:\My Project\.agents\skills"
```

```bash
bash ./install.sh --dest "/path/to/project/.agents/skills"
```

更新时添加 `-Force` 或 `--force`。旧版保存在 skills 目录旁的 `yila-clear-writing-backups` 中，脚本会显示备份路径。

手动安装：将整个 yila-clear-writing 文件夹复制到客户端的 skills 目录。卸载：删除已安装的 yila-clear-writing 文件夹并重新打开客户端。

## 调用

重新打开客户端，在对话中发送：

```text
Codex：$yila-clear-writing 修改下面段落……
Claude Code：/yila-clear-writing 修改下面段落……
```

[完整调用指南](guides/USAGE.zh-CN.md) · [网页通用指令](guides/WEB-PROMPT.zh-CN.md)

## 由 Yila 开源

复制模板后，可与自己的研究材料一起发送到 [Yila 工作台](https://yila.ai/research)。

[许可说明](LICENSE.md) · [OpenAI 安装目录](https://learn.chatgpt.com/docs/build-skills) · [Claude Code 说明](https://code.claude.com/docs/en/skills)
